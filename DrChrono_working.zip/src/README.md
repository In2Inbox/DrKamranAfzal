1. In isdk.php, change line 25, CLIENT_ID = 'YOURCLIENTIDHERE', with the the Id given to you.
2. In isdk.php change line 26, CLIENT_SECRET = 'YOURCLIENTSECRET'
3. In isdk.php change line 27 to the path of your script.
4. index.php and success.php are an example of how to use this isdk with OAuth2
